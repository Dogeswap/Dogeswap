rm -rf build
truffle migrate --reset --compile-all --network development
truffle test